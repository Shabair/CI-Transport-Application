<div class="row">
    <div class="col-lg-12">
    
        <?php if ($this->session->flashdata('success')) :?>
        <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
            <strong><?=$this->session->flashdata('success')?></strong> 
        </div>
        <?php endif;?>
        
        <section  class="panel" id="advanced_search">
            <div class="panel-body">
                <h4 class=""> 
                	
                    <?php 
						$Which_login = $this->session->userdata['which_login'];
						if($Which_login === 'admin')
							{
					?>
                    <strong>Companies List</strong>
                	<a href="<?php echo site_url('Company/add')?>" class="btn btn-primary pull-right" > Add New Company</a>
                    <?php
							}
						else
						{
					?>
                    <strong>Company Profile</strong>
                    <?php 
						} 
					?>
                    </h4>
                <hr style="margin:5px0px;" />
            </div>
        </section>
        <?php
			if($Which_login === 'company')
				{ 
		?>
                    <section class="panel">
                        <div class="panel-body">
                            <div class="row">
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Name :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['name']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Email :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['email']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Phone :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['phone']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                <strong>Cell :</strong>
                                                <span class="pull-right"><?php echo $company_detail['cell']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                <strong>Fax :</strong>
                                                <span class="pull-right"><?php echo $company_detail['fax']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                <strong>City :</strong>
                                                <span class="pull-right"><?php echo $company_detail['city']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong><span>State :</span></strong>
                                                    <span class="pull-right"><?php echo $company_detail['state']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Postal Code :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['postal_code']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="">
                                                <strong>Physical Address :</strong>
                                                <span class="pull-right"><?php echo $company_detail['physical_address'];?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="">
                                                <strong>Mailing Address :</strong>
                                                <span class="pull-right"><?php echo $company_detail['mailing_address']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                <strong>DOT No :</strong>
                                                <span class="pull-right"><?php echo $company_detail['dot_no']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                <strong>MC No :</strong>
                                                <span class="pull-right"><?php echo basename($company_detail['mc_no']); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                <strong>CVOR No :</strong>
                                                <span class="pull-right"><?php echo basename($company_detail['cvor_no']); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">                                    	
                                                <strong>CVOR EXP :</strong>
                                                <span class="pull-right"><?php echo $company_detail['cvor_exp']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                <strong>Insurance Company :</strong>
                                                <span class="pull-right"><?php echo basename($company_detail['ins_company']); ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Insurance Policy No :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['ins_no']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Insurance Expires Date :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['ins_exp']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Insurance Broker Name :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['broker_name']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Broker Phone Number :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['broker_phone']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Broker Fax Number :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['broker_fax']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Broker E-mail :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['broker_email']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>General Liabilities Limit :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['general_limit']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Cargo Liabilities Limit :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['cargo_limit']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Accident Limits :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['accident_limit']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Deductable Cargo :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['deductable_cargo']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Dedicatable Accident :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['dedicatable_accident']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Drug Test Consortium :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['drug_test']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Drug Test DOT :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['drug_test_dot']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Drug Test Non-DOT :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['drug_test_ndot']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>PREPASS Account No :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['prepass_account']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>NMFTA/Scaccode :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['nmfta_scacode']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>NMFTA Expire :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['nmfta_exp']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong> :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['nmfta_scacode2']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>IFTA A/C No :</strong>
                                                    <span class="pull-right">
                                                        <?php 
                                                            echo $company_detail['ifta'].'-'.$company_detail['ifta2'].'-'.$company_detail['ifta3'].'-'.$company_detail['ifta4'].'-'.$company_detail['ifta5']; 
                                                        ?>
                                                    </span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>New Mexico # :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['new_mexico']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Expries :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['mexico_exp']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Orgen # :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['orgen']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Expries :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['orgen_exp']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Msc 90 :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['msc']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Ambassador Bridge :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['ambassador_bridge']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Transponder :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['transponder']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Expries :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['transponder_exp']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>UCR Expire :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['ucr_exp']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Quebec Form :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['quebec_form']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>California Air Resource Board :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['cali_air_res']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>WSIB A/C # :</strong>
                                                    <span class="pull-right"><?php echo $company_detail['wsib']; ?></span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                    <strong>Kentucky :</strong>
                                                    <span class="pull-right">
                                                        <?php 
                                                            echo $company_detail['kentucky'].'-'.$company_detail['kentucky2'].'-'.$company_detail['kentucky3'].'-'.$company_detail['kentucky4']; 
                                                        ?>
                                                    </span>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="">
                                                <strong>Registration Date :</strong>
                                                <span class="pull-right"><?php echo $company_detail['created_date']; ?></span>
                                            </div>
                                        </div>
                                </div>
                        </div>
                    </section>
        <?php 
				}
			if($Which_login === 'admin')
				{ 
		?>
        			<section class="panel">
            <div class="panel-body">
                <div class="adv-table">
                    <table  class="mv_datatable display table table-bordered table-striped table-responsive">
                        <thead>
                            <tr>
								<th>ID</th>
                                <th>Company Name</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>Cell</th>
                                <th>City</th>
                                <th>State</th>
                                <th>Postal-Code</th>
                                <th>Address</th>
								<th>Option</th>
                            </tr>
                        </thead>
                    </table>
                </div>
            </div>
        </section>
        <?php
				}
		?>
    </div>
</div>



<!-- page end-->
<script src="<?php echo base_url(); ?>public/js/jquery.dataTables.min.js"></script>
<script>
function popup_inactive(com_id)
{
	$('#inactive_container');
}
//---------------------------------------------------
var table =	$('.mv_datatable').DataTable( {
		"processing": true,
		"serverSide": true,
		"ajax": "<?=base_url('Company/datatable_json')?>",
		"order": [[0,'desc']],
		"columnDefs": [
			{ "targets": 0, "name": "id", 'searchable':true, 'orderable':true},
			{ "targets": 1, "name": "name", 'searchable':true, 'orderable':true},
			{ "targets": 2, "name": "email", 'searchable':true, 'orderable':true},
			{ "targets": 3, "name": "phone", 'searchable':true, 'orderable':true},
			{ "targets": 4, "name": "cell", 'searchable':true, 'orderable':true},
			{ "targets": 5, "name": "city", 'searchable':true, 'orderable':true},
			{ "targets": 6, "name": "state", 'searchable':true, 'orderable':true},
			{ "targets": 7, "name": "postal_code", 'searchable':true, 'orderable':true},
			{ "targets": 8, "name": "physical_address", 'searchable':true, 'orderable':true},
			{ "targets": 9, "name": "Option", 'searchable':false, 'orderable':false}
			
		]
	});
//---------------------------------------------------
function advance_filter()
{
	$.post('<?=base_url('company/search')?>',$('#company_search').serialize(),function(){
		table.ajax.reload( null, false );
	});
}
	
</script>