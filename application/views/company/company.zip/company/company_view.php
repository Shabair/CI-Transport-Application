<!-- page start-->
<?php isset($company_detail['id'])? $id=$company_detail['id']:  $id='';  ?>

<div class="row">
	<div class="col-lg-12">
		<section class="panel">
			<header class="panel-heading">
				<h4 class="head3" style="display:inline-block"><?php echo isset($company_detail['name'])?$company_detail['name']: '';  ?></h4>
			</header>
			<div class="panel-body">
				<div class="alert alert-success" id="success" style="display:none;"></div>
					<div class=" form">
                    	<form class="cmxform tasi-form" id="frmvalidate" method="post" action="<?php echo site_url('company/add/'.$id); ?>">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Company Name</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['first_name'])?$company_detail['first_name']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Email</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['email'])?$company_detail['email']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Phone Number</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['phone'])?$company_detail['phone']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Cell Number</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['cell'])?$company_detail['cell']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Fax Number</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['fax'])?$company_detail['fax']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Physical Address</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['physical_address'])?$company_detail['physical_address']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Mailing Address</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['mailing_address'])?$company_detail['mailing_address']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row hr-bottom">
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">City</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['city'])?$company_detail['city']: '';  ?>
                                    </div>
                                </div>
                            </div>		
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">State</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['state'])?$company_detail['state']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Postal Code</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['postal_code'])?$company_detail['postal_code']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row hr-bottom">
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">DOT NO.</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['dot_no'])?$company_detail['dot_no']: '';  ?>
                                    </div>
                                </div>
                            </div>		
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">MC NO.</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['mc_no'])?$company_detail['mc_no']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">CVOR NO.</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['cvor_no'])?$company_detail['cvor_no']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">CVOR Expire Date</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['cvor_exp'])?$company_detail['cvor_exp']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                        	<div class="col-md-4">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Insurance Company</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['ins_company'])?$company_detail['ins_company']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Insurance Policy NO.</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['ins_no'])?$company_detail['ins_no']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Insurance Expires Date</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['ins_exp'])?$company_detail['ins_exp']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row hr-bottom">
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Insurance Broker Name</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['broker_name'])?$company_detail['broker_name']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Broker Phone Number</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['broker_phone'])?$company_detail['broker_phone']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Broker Fax Number</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['broker_fax'])?$company_detail['broker_fax']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Broker E-mail</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['broker_email'])?$company_detail['broker_email']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">General Liabilities Limit</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['general_limit'])?$company_detail['general_limit']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Cargo Liabilities Limit</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['cargo_limit'])?$company_detail['cargo_limit']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Accident Limits</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['accident_limit'])?$company_detail['accident_limit']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Deductable Cargo</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['deductable_cargo'])?$company_detail['deductable_cargo']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Dedicatable Accident</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['dedicatable_accident'])?$company_detail['dedicatable_accident']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Drug Test Consortium</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['drug_test'])?$company_detail['drug_test']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Drug Test DOT</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['drug_test_dot'])?$company_detail['drug_test_dot']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Drug Test Non-DOT</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['drug_test_ndot'])?$company_detail['drug_test_ndot']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">PREPASS Account NO.</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['prepass_account'])?$company_detail['prepass_account']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">NMFTA/Scaccode</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['nmfta_scacode'])?$company_detail['nmfta_scacode']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">NMFTA Expire</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['nmfta_exp'])?$company_detail['nmfta_exp']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">&nbsp;</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['nmfta_scacode2'])?$company_detail['nmfta_scacode2']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">IFTA A/C NO.</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['ifta'])?$company_detail['ifta']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                	<label for="cname" class="control-label">&nbsp;</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['ifta2'])?$company_detail['ifta2']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                	<label for="cname" class="control-label">&nbsp;</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['ifta3'])?$company_detail['ifta3']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                	<label for="cname" class="control-label">&nbsp;</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['ifta4'])?$company_detail['ifta4']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                	<label for="cname" class="control-label">&nbsp;</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['ifta5'])?$company_detail['ifta5']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">   
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">New Mexico #</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['new_mexico'])?$company_detail['new_mexico']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Expries</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['mexico_exp'])?$company_detail['mexico_exp']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Orgen #</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['orgen'])?$company_detail['orgen']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Expries</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['orgen_exp'])?$company_detail['orgen_exp']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Msc 90.</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['msc'])?$company_detail['msc']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Ambassador Bridge</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['ambassador_bridge'])?$company_detail['ambassador_bridge']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Transponder</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['transponder'])?$company_detail['transponder']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Expries</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['transponder_exp'])?$company_detail['transponder_exp']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">UCR Expire</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['ucr_exp'])?$company_detail['ucr_exp']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Quebec Form</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['quebec_form'])?$company_detail['quebec_form']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">California Air Resource Board</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['cali_air_res'])?$company_detail['cali_air_res']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">WSIB A/C #</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['wsib'])?$company_detail['wsib']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Kentucky</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['kentucky'])?$company_detail['kentucky']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">&nbsp;</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['kentucky2'])?$company_detail['kentucky2']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">&nbsp;</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['kentucky3'])?$company_detail['kentucky3']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">&nbsp;</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['kentucky4'])?$company_detail['kentucky4']: '';  ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row" style="border-top: 2px solid #FF6C60;padding-top: 15px;margin-top: 15px;">
                        	<div class="col-md-4">
                            </div>
                        	<div class="col-md-2">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Username</label>
                                    <div class="form-control">
                                    <?php echo isset($company_detail['username'])?$company_detail['username']: '';  ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2" style="opacity: 0.5;">
                                <div class="form-group ">
                                    <label for="cname" class="control-label">Password</label>
                                    <div class="form-control" readonly>
                                    ************
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
				</div>
			</div>
		</section>
	</div>
</div>
<!-- page end--> 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.15.1/jquery.validate.min.js"></script> 
<script>
	$('#frmvalidate').validate({
			highlight: function(element) {
			$(element).closest('.form-group').removeClass('has-success').addClass('has-error');
		},
		success: function(element) {
			$(element).closest('.form-group').removeClass('has-error').addClass('has-success');
			$(element).closest('.error').remove();
		},
		ignore:[],
		rules: {
				email: {
					required: true,
					remote: {
						url: "<?php echo base_url('calllist/Check_Email_Exist');?>", 
						type : "post"
					}
				}
		},
		messages: {
	
				email: {
					required: "Please Provide Email Address.",
					remote: "Email Address Already Exists"
				}
		}
		
		$('#frmvalidate').submit();
	});
	
</script>